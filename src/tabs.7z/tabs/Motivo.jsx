import React, { useEffect, useState } from 'react'
import { run, exec } from '../db/index.js'
import { nowIso } from '../utils.js'
export default function Motivo({ encounter }){
  const [v, setV] = useState(encounter?.chief_complaint||''); useEffect(()=>{ setV(encounter?.chief_complaint||'') }, [encounter?.id])
  async function save(){ await run(`UPDATE encounters SET chief_complaint=$v,updated_at=$ua WHERE id=$id`, { $v:v, $id:encounter.id, $ua:nowIso() }); alert('Guardado') }
  return (<div><label>Motivo de consulta<textarea value={v} onChange={e=>setV(e.target.value)} /></label><button onClick={save}>Guardar</button></div>) }