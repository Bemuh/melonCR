import React from 'react'
import { useUI } from '../store/ui.js'
const order = [
  ['datos','Datos del paciente'],['motivo','Motivo'],['hpi','Enfermedad actual'],['antecedentes','Antecedentes'],
  ['examen','Examen físico'],['vitales','Signos vitales'],['diagnosticos','Diagnósticos (CIE-10)'],['plan','Plan/Conducta'],
  ['formula','Fórmula médica'],['procedimientos','Procedimientos'],['adjuntos','Adjuntos'],['evoluciones','Evoluciones']
]
export default function Tabs(){ const { activeTab, setTab } = useUI()
  return (<div className='tabs no-print'>{order.map(([k,l]) => (<div key={k} className={'tab ' + (activeTab===k?'active':'')} onClick={()=>setTab(k)}>{l}</div>))}</div>)
}