import React, { useEffect, useState } from 'react'
import { run, exec } from '../db/index.js'
import { nowIso } from '../utils.js'
export default function Antecedentes({ encounter }){
  const [v, setV] = useState(encounter?.antecedentes||''); useEffect(()=>{ setV(encounter?.antecedentes||'') }, [encounter?.id])
  async function save(){ await run(`UPDATE encounters SET antecedentes=$v,updated_at=$ua WHERE id=$id`, { $v:v, $id:encounter.id, $ua:nowIso() }); alert('Guardado') }
  return (<div><label>Antecedentes<textarea value={v} onChange={e=>setV(e.target.value)} /></label><button onClick={save}>Guardar</button></div>) }