import React, { useEffect, useState } from 'react'
import { run, exec } from '../db/index.js'
import { nowIso } from '../utils.js'
export default function Diagnosticos({ encounter }){
  const [list,setList]=useState([]),[code,setCode]=useState(''),[label,setLabel]=useState(''),[primary,setPrimary]=useState(false),[dtype,setDtype]=useState('presuntivo')
  useEffect(()=>{ reload() },[encounter?.id])
  function reload(){ setList(exec(`SELECT * FROM diagnoses WHERE encounter_id=$id`, { $id:encounter.id })) }
  async function add(){ if(!code||!label) return alert('CIE-10 código + nombre'); await run(`INSERT INTO diagnoses (id, encounter_id, code, label, is_primary, diagnosis_type) VALUES ($id,$e,$c,$l,$p,$t)`, { $id:crypto.randomUUID(), $e:encounter.id, $c:code, $l:label, $p:primary?1:0, $t:dtype }); setCode(''); setLabel(''); setPrimary(false); reload() }
  async function del(id){ await run(`DELETE FROM diagnoses WHERE id=$id`, { $id:id }); reload() }
  return (<div><div className='row'>
      <label>Código CIE-10<input value={code} onChange={e=>setCode(e.target.value)} placeholder='M43.6' /></label>
      <label>Nombre<input value={label} onChange={e=>setLabel(e.target.value)} placeholder='Tortícolis' /></label>
      <label>Tipo
        <select value={dtype} onChange={e=>setDtype(e.target.value)}>
          <option value='impresion'>1 - Impresión Diagnóstica</option>
          <option value='confirmado_nuevo'>2 - Confirmado nuevo</option>
          <option value='confirmado_repetido'>3 - Confirmado repetido</option>
        </select>
      </label>
  <label className="inline-center no-grow self-center">
    <input
      type="checkbox"
      checked={primary}
      onChange={e => setPrimary(e.target.checked)}
    />
    Principal
  </label>
    </div><button onClick={add}>Agregar</button><hr/><ul>
      {list.map(dx => (<li key={dx.id}>{dx.is_primary? 'Principal':'Secundario'} — {dx.code} {dx.label} ({dx.diagnosis_type}) <button className='ghost' onClick={()=>del(dx.id)}>Eliminar</button></li>))}
    </ul></div>) }