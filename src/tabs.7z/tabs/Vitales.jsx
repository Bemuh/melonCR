import React, { useEffect, useState } from 'react'
import { run, exec } from '../db/index.js'
import { nowIso } from '../utils.js'
export default function Vitales({ encounter }){
  const [taS,setTaS]=useState(''),[taD,setTaD]=useState(''),[fc,setFc]=useState(''),[fr,setFr]=useState('')
  const [temp,setTemp]=useState(''),[spo2,setSpo2]=useState(''),[talla,setTalla]=useState(''),[peso,setPeso]=useState('')
  useEffect(()=>{ try{ const v = encounter?.vitals_json? JSON.parse(encounter.vitals_json):{}; setTaS(v.taS||''); setTaD(v.taD||''); setFc(v.fc||''); setFr(v.fr||''); setTemp(v.temp||''); setSpo2(v.spo2||''); setTalla(v.talla||''); setPeso(v.peso||'') }catch{} },[encounter?.id])
  const bmi = (Number(peso)&&Number(talla)) ? (Number(peso)/((Number(talla)/100)**2)).toFixed(1) : ''
  async function save(){ const data={taS,taD,fc,fr,temp,spo2,talla,peso,bmi}; await run(`UPDATE encounters SET vitals_json=$v,updated_at=$ua WHERE id=$id`, { $v:JSON.stringify(data), $id:encounter.id, $ua:nowIso() }); alert('Guardado') }
  return (<div><div className='row'>
    <label>TA Sistólica<input value={taS} onChange={e=>setTaS(e.target.value)} /></label>
    <label>TA Diastólica<input value={taD} onChange={e=>setTaD(e.target.value)} /></label>
    <label>FC<input value={fc} onChange={e=>setFc(e.target.value)} /></label>
    <label>FR<input value={fr} onChange={e=>setFr(e.target.value)} /></label>
  </div><div className='row'>
    <label>Temperatura °C<input value={temp} onChange={e=>setTemp(e.target.value)} /></label>
    <label>SatO₂ %<input value={spo2} onChange={e=>setSpo2(e.target.value)} /></label>
    <label>Talla (cm)<input value={talla} onChange={e=>setTalla(e.target.value)} /></label>
    <label>Peso (kg)<input value={peso} onChange={e=>setPeso(e.target.value)} /></label>
  </div><div className='small'>IMC: <span className='badge'>{bmi||'-'}</span></div><button onClick={save}>Guardar</button></div>) }