import React, { useEffect, useState } from 'react'
import { run, exec } from '../db/index.js'
import { nowIso } from '../utils.js'
export default function Evoluciones(){ return <div className='small'>Evoluciones — Pendiente definir contenido.</div> }