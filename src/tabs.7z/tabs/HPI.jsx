import React, { useEffect, useState } from 'react'
import { run, exec } from '../db/index.js'
import { nowIso } from '../utils.js'
export default function HPI({ encounter }){
  const [v, setV] = useState(encounter?.hpi||''); useEffect(()=>{ setV(encounter?.hpi||'') }, [encounter?.id])
  async function save(){ await run(`UPDATE encounters SET hpi=$v,updated_at=$ua WHERE id=$id`, { $v:v, $id:encounter.id, $ua:nowIso() }); alert('Guardado') }
  return (<div><label>Enfermedad actual<textarea value={v} onChange={e=>setV(e.target.value)} /></label><button onClick={save}>Guardar</button></div>) }