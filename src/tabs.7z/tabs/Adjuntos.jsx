import React, { useEffect, useState } from 'react'
import { run, exec } from '../db/index.js'
import { nowIso } from '../utils.js'
export default function Adjuntos(){ return <div className='small'>Adjuntos — Pendiente definir metadatos.</div> }