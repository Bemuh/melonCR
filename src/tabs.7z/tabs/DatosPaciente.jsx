import React, { useEffect, useState } from 'react'
import { run, exec } from '../db/index.js'
import { nowIso } from '../utils.js'
export default function DatosPaciente({ patient }){
  const [p, setP] = useState(patient); useEffect(()=>{ setP(patient) }, [patient?.id])
  async function save(){ await run(`UPDATE patients SET phone=$ph,email=$em,address=$ad,city=$cy,updated_at=$ua WHERE id=$id`, { $ph:p.phone||'', $em:p.email||'', $ad:p.address||'', $cy:p.city||'', $id:p.id, $ua:nowIso() }); alert('Guardado') }
  return (<div><div className='row'>
    <label>Teléfono<input value={p.phone||''} onChange={e=>setP({...p, phone:e.target.value})} /></label>
    <label>Email<input value={p.email||''} onChange={e=>setP({...p, email:e.target.value})} /></label>
    <label>Dirección<input value={p.address||''} onChange={e=>setP({...p, address:e.target.value})} /></label>
    <label>Ciudad<input value={p.city||''} onChange={e=>setP({...p, city:e.target.value})} /></label>
  </div><button onClick={save}>Guardar</button></div>) }