import React, { useEffect, useState } from 'react'
import { run, exec } from '../db/index.js'
import { nowIso } from '../utils.js'
export default function ExamenFisico({ encounter }){
  const [v, setV] = useState(encounter?.physical_exam||''); useEffect(()=>{ setV(encounter?.physical_exam||'') }, [encounter?.id])
  async function save(){ await run(`UPDATE encounters SET physical_exam=$v,updated_at=$ua WHERE id=$id`, { $v:v, $id:encounter.id, $ua:nowIso() }); alert('Guardado') }
  return (<div><label>Examen físico<textarea value={v} onChange={e=>setV(e.target.value)} /></label><button onClick={save}>Guardar</button></div>) }